import { useParams, Link } from "wouter";
import { useGetFlight, getGetFlightQueryKey, useGetFlightPoints, getGetFlightPointsQueryKey, FlightPoint } from "@workspace/api-client-react";
import { Layout } from "@/components/layout/layout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FlightTelemetryCharts } from "@/components/flight/flight-telemetry-charts";
import { FlightEngineCharts } from "@/components/flight/flight-engine-charts";
import { FlightReplay } from "@/components/flight/flight-replay";
import { FlightVoltageChart } from "@/components/flight/flight-voltage-chart";
import { FlightCASLog } from "@/components/flight/flight-cas-log";
import { FlightSummary } from "@/components/flight/flight-summary";
import { AlertTriangle, ArrowLeft, Loader2, Calendar } from "lucide-react";
import { format, parseISO } from "date-fns";

const EMPTY: FlightPoint[] = [];

export default function FlightDetail() {
  const { id } = useParams();
  const flightId = parseInt(id || "0", 10);

  const { data: flight, isLoading: loadingFlight } = useGetFlight(flightId, {
    query: { enabled: !!flightId, queryKey: getGetFlightQueryKey(flightId) },
  });

  const { data: points, isLoading: loadingPoints } = useGetFlightPoints(flightId, {
    query: { enabled: !!flightId, queryKey: getGetFlightPointsQueryKey(flightId) },
  });

  if (loadingFlight) {
    return (
      <Layout>
        <div className="flex-1 flex items-center justify-center">
          <div className="flex flex-col items-center gap-4 text-primary">
            <Loader2 className="w-8 h-8 animate-spin" />
            <span className="font-mono text-sm tracking-widest">LOADING TELEMETRY...</span>
          </div>
        </div>
      </Layout>
    );
  }

  if (!flight) {
    return (
      <Layout>
        <div className="p-12 text-center flex flex-col items-center justify-center">
          <div className="bg-card p-8 rounded-md border border-border max-w-md w-full">
            <AlertTriangle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2">Flight Not Found</h3>
            <p className="text-muted-foreground text-sm mb-6">
              The requested flight log could not be located in the database.
            </p>
            <Link href="/">
              <span className="text-primary hover:underline font-mono text-sm tracking-wider uppercase">
                Return to logbook
              </span>
            </Link>
          </div>
        </div>
      </Layout>
    );
  }

  const safePoints = points ?? EMPTY;
  const alerts = Array.from(
    new Set(safePoints.filter((p) => p.alerts).map((p) => p.alerts!))
  );

  return (
    <Layout>
      <div className="max-w-7xl mx-auto w-full p-6 space-y-8">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-6">
            <Link href="/">
              <div className="w-10 h-10 rounded-md bg-card border border-border flex items-center justify-center hover:bg-muted hover:text-primary cursor-pointer transition-colors group">
                <ArrowLeft className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
              </div>
            </Link>
            <div>
              <h2 className="text-3xl font-bold tracking-tight flex items-center gap-3">
                {flight.aircraftIdent || "Unknown Tail"}
                <span className="text-xs font-mono bg-primary/10 text-primary px-2 py-1 rounded border border-primary/20 tracking-wider">
                  {flight.product || "GDU 460"}
                </span>
              </h2>
              <div className="text-sm font-mono text-muted-foreground mt-2 flex items-center gap-6">
                <span className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  {flight.startTime
                    ? format(parseISO(flight.startTime), "MMMM d, yyyy HH:mm")
                    : "Unknown Date"}
                </span>
                <span className="opacity-50">/</span>
                <span>DURATION: {formatDuration(flight.startTime, flight.endTime)}</span>
                <span className="opacity-50">/</span>
                <span>POINTS: {flight.totalPoints}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Alerts */}
        {alerts.length > 0 && (
          <div className="bg-amber-500/10 border border-amber-500/20 rounded-md p-4 flex flex-col gap-3">
            <div className="flex items-center gap-2 text-amber-500 font-bold text-sm uppercase tracking-widest">
              <AlertTriangle className="w-4 h-4" /> System Alerts Logged
            </div>
            <div className="flex flex-wrap gap-2">
              {alerts.map((a, i) => (
                <span
                  key={i}
                  className="text-xs font-mono bg-amber-500/20 text-amber-400 px-3 py-1 rounded border border-amber-500/30 tracking-wider"
                >
                  {a}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Detailed flight summary — computed from telemetry points */}
        <FlightSummary points={safePoints} loading={loadingPoints} />

        <Tabs defaultValue="replay" className="w-full">
          <TabsList className="w-full justify-start bg-card border-b border-border rounded-none p-0 h-auto flex-wrap">
            <TabsTrigger value="replay" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:text-primary px-6 py-4 font-mono uppercase text-sm tracking-wider">
              Replay G3X
            </TabsTrigger>
            <TabsTrigger value="telemetry" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:text-primary px-6 py-4 font-mono uppercase text-sm tracking-wider">
              Telemetría
            </TabsTrigger>
            <TabsTrigger value="engine" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:text-primary px-6 py-4 font-mono uppercase text-sm tracking-wider">
              Motor
            </TabsTrigger>
            <TabsTrigger value="voltage" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:text-primary px-6 py-4 font-mono uppercase text-sm tracking-wider">
              Voltaje
            </TabsTrigger>
            <TabsTrigger value="cas" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:text-primary px-6 py-4 font-mono uppercase text-sm tracking-wider">
              Mensajes CAS
            </TabsTrigger>
          </TabsList>

          <TabsContent value="replay" className="mt-6 m-0 focus-visible:outline-none">
            {loadingPoints ? <TabLoading /> : <FlightReplay points={safePoints} />}
          </TabsContent>
          <TabsContent value="telemetry" className="mt-6 m-0 focus-visible:outline-none">
            {loadingPoints ? <TabLoading /> : <FlightTelemetryCharts points={safePoints} />}
          </TabsContent>
          <TabsContent value="engine" className="mt-6 m-0 focus-visible:outline-none">
            {loadingPoints ? <TabLoading /> : <FlightEngineCharts points={safePoints} />}
          </TabsContent>
          <TabsContent value="voltage" className="mt-6 m-0 focus-visible:outline-none">
            {loadingPoints ? <TabLoading /> : <FlightVoltageChart points={safePoints} />}
          </TabsContent>
          <TabsContent value="cas" className="mt-6 m-0 focus-visible:outline-none">
            {loadingPoints ? <TabLoading /> : <FlightCASLog points={safePoints} />}
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}

function TabLoading() {
  return (
    <div className="h-64 flex flex-col gap-4 items-center justify-center text-primary">
      <Loader2 className="w-8 h-8 animate-spin" />
      <span className="font-mono text-sm tracking-widest uppercase">Fetching data blocks...</span>
    </div>
  );
}

function StatBox({
  label,
  value,
  unit,
  alert = false,
}: {
  label: string;
  value: any;
  unit: string;
  alert?: boolean;
}) {
  return (
    <div
      className={`bg-card p-5 rounded-md border ${
        alert ? "border-destructive bg-destructive/10" : "border-border"
      } flex flex-col`}
    >
      <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
        {label}
      </span>
      <div className="mt-2 flex items-baseline gap-1">
        <span
          className={`text-3xl font-mono font-bold tracking-tight ${
            alert ? "text-destructive" : "text-foreground"
          }`}
        >
          {value ?? "--"}
        </span>
        <span className="text-xs font-mono text-muted-foreground">{unit}</span>
      </div>
    </div>
  );
}

function formatDuration(start?: string | null, end?: string | null) {
  if (!start || !end) return "--";
  const startDate = parseISO(start);
  const endDate = parseISO(end);
  const diffMins = Math.round((endDate.getTime() - startDate.getTime()) / 60000);
  const hrs = Math.floor(diffMins / 60);
  const mins = diffMins % 60;
  return `${hrs}h ${mins}m`;
}
